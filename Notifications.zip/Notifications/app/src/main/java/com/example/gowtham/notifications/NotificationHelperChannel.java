package com.example.gowtham.notifications;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Color;
import android.os.Build;

public class NotificationHelperChannel extends ContextWrapper {
    private static final String ID="com.example.gowtham.notifications";
    private static final String NAME="pavani";
    NotificationManager nm;

    public NotificationHelperChannel(Context base) {
        super(base);
        createChannel();
    }

    public void createChannel() {
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name="personal details";
            String description="this is  android class";
            int imprtance=NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel=new NotificationChannel(ID,name,imprtance);
            channel.setDescription(description);
            nm.createNotificationChannel(channel);
            getMagager().createNotificationChannel(channel);

        }*/
        NotificationChannel channel=new NotificationChannel(ID,NAME,NotificationManager.IMPORTANCE_DEFAULT);
        channel.setLightColor(Color.GREEN);
        channel.enableVibration(true);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        getMagager().createNotificationChannel(channel);
    }
    private NotificationManager getMagager(){
        if (nm==null)
             nm= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        return nm;
    }
    public Notification.Builder getNotification_Channel(){
        return new Notification.Builder(getApplicationContext(),ID);
    }
}
