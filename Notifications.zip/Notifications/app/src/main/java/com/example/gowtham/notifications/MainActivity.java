package com.example.gowtham.notifications;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    NotificationManager notificationManager;
    NotificationCompat.Builder builder;
    private static final int NOTIFICATION_ID=1234567890;
    PendingIntent pi;
    Intent intent;
    NotificationHelperChannel nc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        nc=new NotificationHelperChannel(this);
        setContentView(R.layout.activity_main);
        notificationManager= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        intent=new Intent(this,MyNotificationActivity.class);
        pi=PendingIntent.getActivity(this,NOTIFICATION_ID,intent,PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public void showNotification(View view){
       Notification.Builder builder= nc.getNotification_Channel();
       nc.nm.notify(0,builder.build());

        /*builder=new NotificationCompat.Builder(this);
        builder.setContentTitle("APSSDC");
        builder.setContentText("HELLO SRIT ATP");
        builder.setSmallIcon(R.drawable.ic_notifications_none_black_24dp);
        builder.setContentIntent(pi);
        builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        builder.addAction(R.drawable.ic_reply_black_24dp,getString(R.string.reply),pi);
        Bitmap bitmap=BitmapFactory.decodeResource(getResources(),R.drawable.ap);
        builder.setStyle(new NotificationCompat.BigPictureStyle().bigPicture(bitmap));
        Notification notification=builder.build();
        notificationManager.notify(NOTIFICATION_ID,notification);*/
    }
}
